// Common/Types.h

#ifndef __COMMON_TYPES_H
#define __COMMON_TYPES_H

#include "../../C/Types.h"

typedef int HRes;

#endif

